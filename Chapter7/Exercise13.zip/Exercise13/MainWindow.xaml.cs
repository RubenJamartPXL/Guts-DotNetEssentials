﻿using System;
using System.Windows;

namespace Exercise13
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void berekenButton_Click(object sender, RoutedEventArgs e)
        {
            int getal = Convert.ToInt32(_priceTextBox.Text);
            if (_checkBox.IsChecked == false)
            {
                _btwTextBox.Content = getal * 0.21;
                _totalTextBox.Content = getal + getal * 0.21;
            }
            else
            {
                _btwTextBox.Content = getal * 0.06;
                _totalTextBox.Content = getal + getal * 0.06;
            }
        }
    }
}
